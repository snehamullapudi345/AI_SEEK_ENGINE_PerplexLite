import os
from google import genai
from dotenv import load_dotenv

load_dotenv()
API_KEY = os.getenv("GOOGLE_API_KEY")

try:
    client = genai.Client(api_key=API_KEY)
    # Simple tiny request to check validity
    response = client.models.generate_content(
        model='gemini-1.5-flash',
        contents="hi"
    )
    print("SUCCESS: Key is valid and active.")
    print(f"Response: {response.text}")
except Exception as e:
    print(f"ERROR: {e}")
