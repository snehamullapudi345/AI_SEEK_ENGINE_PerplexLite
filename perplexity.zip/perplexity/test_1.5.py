import os
from google import genai
from dotenv import load_dotenv

load_dotenv()
API_KEY = os.getenv("GOOGLE_API_KEY")

try:
    client = genai.Client(api_key=API_KEY)
    print("Trying to generate with gemini-1.5-flash-002...")
    response = client.models.generate_content(
        model='gemini-1.5-flash-002',
        contents="hi"
    )
    print(f"SUCCESS: {response.text}")
except Exception as e:
    print(f"ERROR: {e}")
