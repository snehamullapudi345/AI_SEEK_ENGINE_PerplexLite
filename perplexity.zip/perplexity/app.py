import os
import base64
from flask import Flask, render_template, request, Response, stream_with_context
from google import genai
from dotenv import load_dotenv

# --- Initialization ---
load_dotenv()

app = Flask(__name__)

# Configure Google GenAI Client
API_KEY = os.getenv("GOOGLE_API_KEY")
client = genai.Client(api_key=API_KEY)

# Global conversation memory
conversation_history = []

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    try:
        # Handle Multi-modal (Image + Text)
        user_message = ""
        image_data = None
        mime_type = None
        model_name = request.form.get('model', 'RISE Sonar') # Default to Sonar

        # Map frontend model names to Gemini model IDs
        model_id = "gemini-2.0-flash" # Reverted to 2.0-flash for best performace
        if "Pro" in model_name:
            model_id = "gemini-2.0-flash" 
        elif "Lite" in model_name:
            model_id = "gemini-1.5-flash"

        if request.content_type.startswith('multipart/form-data'):
            user_message = request.form.get('message', '')
            if 'image' in request.files:
                file = request.files['image']
                image_data = file.read()
                mime_type = file.content_type
        else:
            user_message = request.json.get('message', '')
            model_name = request.json.get('model', 'RISE Sonar')

        if not user_message and not image_data:
            return Response("No message provided", status=400)

        # Construct Parts
        parts = []
        if user_message: parts.append({"text": user_message})
        if image_data:
            parts.append({
                "inline_data": {
                    "data": base64.b64encode(image_data).decode('utf-8'),
                    "mime_type": mime_type
                }
            })

        # Add user turn to history
        conversation_history.append({"role": "user", "parts": parts})

        def generate():
            try:
                # Using gemini-2.0-flash as the requested "2.5 flash" level model
                response_stream = client.models.generate_content(
                    model=model_id, 
                    contents=conversation_history,
                    config={
                        'system_instruction': (
                            f"You are RISE AI, operating in {model_name} mode. "
                            "Provide helpful, precise, and professional responses in Markdown. "
                            "If you are in 'Sonar' mode, focus on search and reasoning. "
                            "If in 'Pro' mode, excel in deep logic and complex tasks."
                        )
                    }
                )
                
                full_reply = ""
                for chunk in response_stream:
                    if hasattr(chunk, 'text') and chunk.text:
                        full_reply += chunk.text
                        yield chunk.text

                # Save model turn to history
                conversation_history.append({
                    "role": "model",
                    "parts": [{"text": full_reply}]
                })
                
            except Exception as e:
                if len(conversation_history) > 0 and conversation_history[-1]['role'] == 'user':
                    conversation_history.pop()
                print(f"Gemini Service Error: {e}")
                yield f"RISE Error: The AI service is currently unavailable. Please verify your API key or model availability."

        return Response(stream_with_context(generate()), mimetype='text/plain')

    except Exception as e:
        print(f"General Error: {e}")
        return Response(f"Internal Server Error: {str(e)}", status=500)

@app.route('/reset', methods=['POST'])
def reset():
    global conversation_history
    conversation_history.clear()
    return "History cleared", 200

if __name__ == '__main__':
    app.run(debug=True, port=8000)
