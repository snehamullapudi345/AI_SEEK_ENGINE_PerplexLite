import os
from google import genai
from dotenv import load_dotenv

load_dotenv()
API_KEY = os.getenv("GOOGLE_API_KEY")

try:
    client = genai.Client(api_key=API_KEY)
    print("Available Models:")
    for model in client.models.list():
        print(f" - {model.name}")
except Exception as e:
    print(f"ERROR: {e}")
