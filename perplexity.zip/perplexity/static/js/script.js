document.addEventListener('DOMContentLoaded', () => {
    const chatInput = document.getElementById('chat-input');
    const submitBtn = document.querySelector('.btn-submit');
    const messagesList = document.getElementById('chat-messages');
    const chatContainer = document.querySelector('.chat-container');
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebar-toggle');
    const themeToggle = document.getElementById('theme-toggle');
    const newChatBtn = document.getElementById('new-chat-btn');
    const chips = document.querySelectorAll('.chip');
    const suggestions = document.querySelector('.suggestions');
    const appMain = document.querySelector('.app-main');

    // --- Multi-Modal Elements ---
    const attachBtn = document.getElementById('attach-btn');
    const imageUpload = document.getElementById('image-upload');
    const imagePreviewContainer = document.getElementById('image-preview-container');
    const imagePreview = document.getElementById('image-preview');
    const removeImageBtn = document.getElementById('remove-image');
    const analyzeChip = document.getElementById('analyze-chip');

    let isSidebarOpen = window.innerWidth > 768;
    let isDarkMode = localStorage.getItem('theme') === 'dark';
    let selectedFile = null;

    // --- Theme & Sidebar Logic ---
    sidebarToggle.addEventListener('click', () => {
        isSidebarOpen = !isSidebarOpen;
        if (isSidebarOpen) { sidebar.classList.remove('closed'); appMain.classList.remove('full-width'); } 
        else { sidebar.classList.add('closed'); appMain.classList.add('full-width'); }
    });

    if (isDarkMode) document.body.setAttribute('data-theme', 'dark');
    updateThemeIcons();
    themeToggle.addEventListener('click', () => {
        isDarkMode = !isDarkMode;
        document.body.toggleAttribute('data-theme', isDarkMode);
        localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
        updateThemeIcons();
    });

    function updateThemeIcons() {
        document.querySelector('.moon-icon').style.display = isDarkMode ? 'none' : 'block';
        document.querySelector('.sun-icon').style.display = isDarkMode ? 'block' : 'none';
    }

    // --- Multi-Modal Handling ---
    attachBtn.addEventListener('click', () => imageUpload.click());
    analyzeChip.addEventListener('click', () => imageUpload.click());
    imageUpload.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file && file.type.startsWith('image/')) {
            selectedFile = file;
            const reader = new FileReader();
            reader.onload = (e) => {
                imagePreview.src = e.target.result;
                imagePreviewContainer.style.display = 'flex';
                submitBtn.disabled = false;
            };
            reader.readAsDataURL(file);
        }
    });
    removeImageBtn.addEventListener('click', () => {
        selectedFile = null; imageUpload.value = '';
        imagePreviewContainer.style.display = 'none';
        submitBtn.disabled = chatInput.value.trim().length === 0;
    });

    // --- Streaming Chat Logic ---
    async function handleSendMessage() {
        const message = chatInput.value.trim();
        const model = currentModelName.innerText; // Get from model selector
        if (!message && !selectedFile) return;

        const formData = new FormData();
        if (message) formData.append('message', message);
        formData.append('model', model); // Send selected model
        if (selectedFile) formData.append('image', selectedFile);
        const currentImage = selectedFile ? URL.createObjectURL(selectedFile) : null;

        // Reset UI
        chatInput.value = ''; chatInput.style.height = 'auto';
        if (selectedFile) removeImageBtn.click();
        submitBtn.setAttribute('disabled', 'true');

        const greeting = document.querySelector('.greeting');
        if (greeting) greeting.style.display = 'none';
        if (suggestions) suggestions.style.display = 'none';
        chatContainer.style.justifyContent = 'flex-start';

        appendMessage('user', message, false, currentImage);
        const loadingId = appendMessage('ai', '', true); // Placeholder for stream

        try {
            const response = await fetch('/chat', {
                method: 'POST',
                body: formData,
            });

            if (!response.ok) throw new Error('Server error');

            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            const aiMessageContent = document.getElementById(loadingId).querySelector('.message-content');
            aiMessageContent.classList.add('streaming');
            
            let fullText = "";
            while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                
                const chunk = decoder.decode(value, { stream: true });
                fullText += chunk;
                
                // Update live with formatting
                aiMessageContent.innerHTML = marked.parse(fullText);
                Prism.highlightAllUnder(aiMessageContent);
                addCopyButtons(); // Add buttons to streaming blocks
                messagesList.scrollTop = messagesList.scrollHeight;
            }
            
            aiMessageContent.classList.remove('streaming');
            addCopyButtons(); // Final pass
            
        } catch (error) {
            const el = document.getElementById(loadingId);
            if (el) el.querySelector('.message-content').innerText = 'Error: ' + error.message;
        }
    }

    function appendMessage(role, text, isStream = false, imageUrl = null) {
        const messageId = 'msg-' + Date.now();
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${role}-message`;
        messageDiv.id = messageId;

        const iconHtml = role === 'user' 
            ? `<div class="message-icon user-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle>
                </svg>
               </div>`
            : `<div class="message-icon ai-icon">
                <img src="/static/img/logo.svg" width="24" height="24" alt="RISE">
               </div>`;

        const imageHtml = imageUrl ? `<img src="${imageUrl}" class="message-image" alt="Uploaded Image">` : '';

        messageDiv.innerHTML = `
            ${iconHtml}
            <div class="message-content">${imageHtml}${marked.parse(text || '')}</div>
        `;

        messagesList.appendChild(messageDiv);
        addCopyButtons(); // Add buttons to static blocks
        messagesList.scrollTop = messagesList.scrollHeight;
        return messageId;
    }

    // --- Model Selector Logic ---
    const modelSelector = document.getElementById('model-selector');
    const modelDropdown = document.getElementById('model-dropdown');
    const modelOptions = document.querySelectorAll('.model-option');
    const currentModelName = document.getElementById('current-model-name');

    modelSelector.addEventListener('click', (e) => {
        e.stopPropagation();
        modelDropdown.classList.toggle('show');
    });

    document.addEventListener('click', () => modelDropdown.classList.remove('show'));

    modelOptions.forEach(option => {
        option.addEventListener('click', () => {
            const model = option.getAttribute('data-model');
            currentModelName.innerText = model;
            modelOptions.forEach(opt => opt.classList.remove('active'));
            option.classList.add('active');
            modelDropdown.classList.remove('show');
        });
    });

    // --- Suggestion Chips Logic ---
    chips.forEach(chip => {
        chip.addEventListener('click', () => {
            if (chip.id === 'analyze-chip') {
                imageUpload.click();
            } else if (chip.classList.contains('chip-more')) {
                // Future "See more" functionality could go here
            } else {
                const prompt = chip.innerText.trim();
                chatInput.value = prompt;
                handleSendMessage();
            }
        });
    });

    // --- Copy Code Utility ---
    function addCopyButtons() {
        const codeBlocks = document.querySelectorAll('pre');
        codeBlocks.forEach(block => {
            if (block.querySelector('.copy-btn')) return;

            const button = document.createElement('button');
            button.className = 'copy-btn';
            button.innerText = 'Copy';
            button.addEventListener('click', () => {
                const code = block.querySelector('code').innerText;
                navigator.clipboard.writeText(code).then(() => {
                    button.innerText = 'Copied!';
                    setTimeout(() => button.innerText = 'Copy', 2000);
                });
            });
            block.style.position = 'relative';
            block.appendChild(button);
        });
    }

    // --- Handlers ---
    newChatBtn.addEventListener('click', async () => {
        if (confirm('Start a new session?')) {
            await fetch('/reset', { method: 'POST' });
            window.location.reload();
        }
    });

    chatInput.addEventListener('input', function() {
        submitBtn.disabled = this.value.trim().length === 0 && !selectedFile;
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight > 200 ? 200 : this.scrollHeight) + 'px';
    });

    chatInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage(); }
    });

    submitBtn.addEventListener('click', handleSendMessage);
});
